/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/J2EE/EJB30/StatelessEjbClass.java to edit this template
 */
package co.edu.javeriana.as.view.util;

import co.edu.javeriana.as.persona.beans.PersonaFacadeLocal;
import co.edu.javeriana.as.persona.model.Persona;
import java.util.List;
import javax.ejb.EJB;
import javax.ejb.Stateless;
import javax.ejb.LocalBean;
import javax.faces.bean.ManagedBean;
import javax.inject.Named;


@Stateless
@LocalBean
@ManagedBean
public class ContextMenuView {
    
    private Persona selected;
    @EJB
    PersonaFacadeLocal pf;
    private List<Persona> personas;

    public List<Persona> getProducts() {
        return personas;
    }
    public ContextMenuView(){
        this.selected=new Persona();
    }

    public Persona getSelected() {
        return selected;
    }

    public void setSelected(Persona selectedP) {
        this.selected = selectedP;
    }
    public void create(){
        pf.create(selected);
    }
    public void delete(){
        List<Persona> pers=pf.findCC(selected.getCc());
        Persona p= pers.get(0);
        pf.remove(p);
    }
     public void edit(){
        pf.edit(selected);
    }
    public List<Persona> getItems(){
        personas=pf.findAll();
        return personas;
    }
    
}
